

#tipos de dados
idade = 10
print(type(idade))
print(idade)
input('tecle para continuar')

resultado = False
print(resultado)
print(type(resultado))
input('tecle para continuar')

nome = 'Marcos '
sobrenome = 'Castro'
nome_completo = nome + sobrenome
print(nome_completo)
print(type(nome_completo))
input('tecle para continuar')

#conteudo de arquivos, dataframe
lista = ['Julia','Marcelo','Gabriela']
print(lista[0])
print(type(lista))

#buckets, ec2
dicionario =  {'marcos':28, 'maria':20, 'pedro':18}
print(dicionario['marcos'])
print(type(dicionario))


#set
# Declaração de um set
meu_set = {1, 2, 3, 4, 1}
print(type(meu_set))
meu_set.add(2)





